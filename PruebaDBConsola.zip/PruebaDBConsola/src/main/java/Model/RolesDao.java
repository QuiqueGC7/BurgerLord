package Model;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.SQLOutput;
import java.util.ArrayList;

public class RolesDao implements IDao{
    private final String SQL_FIND = "SELECT * from ROLES WHERE 1=1 ";
    private final String SQL_DELETE = "DELETE * from ROLES WHERE ";

    private IMotorSQL motorSQL;
    public RolesDao(){
        motorSQL = new MotorSQL();
        //motorSQL = new MotorOracle();
    }

    @Override
    public int add(Object bean) {
        return 0;
    }

    @Override
    public int delete(Object e) {
        //Comprobar el tipo de objeto para asignarlo al id de elemento iElement
        Integer idRol = -1;
        Integer iRet = -1;
        if (e instanceof Integer){
            idRol = (Integer)e;
        } else if (e instanceof Roles) {
            idRol = ((Roles)e).getRole_ID();
        }
        String sql = SQL_DELETE;
        if (idRol>0){
            try{
                motorSQL.connect();
                sql += " ID_ROLES = ?";
                motorSQL.execute();
            } finally {
                motorSQL.disconnect();
            }
        }
        return iRet;
    }

    @Override
    public int update(Object bean) {
        return 0;
    }

    @Override
    public ArrayList findAll(Object bean) {
        ArrayList<Roles> roles = new ArrayList<Roles>();
        String sql = SQL_FIND;
        try{
            motorSQL.connect();

            if (bean != null){
                Roles rol = (Roles)bean;

                if (rol.getRole_ID() >= 0)
                {
                    sql += "AND ROL_ID ='"+ rol.getRole_ID() + "'";
                }
                if (rol.getRole_Name() != "") {
                    sql += "AND NAME_ID ='" + rol.getRole_Name() + "'";
                }
            }
            ResultSet rs =motorSQL.executeQuery(sql);
            while (rs.next()){
                Roles rolDB = new Roles(
                        rs.getInt("ROLE_ID"),
                        rs.getString("ROLE_NAME")
                );
                roles.add(rolDB);
            }
        }
        catch (SQLException e){
            System.out.println(e);
        }
        finally {
            motorSQL.disconnect();
        }

        return roles;
    }
}
