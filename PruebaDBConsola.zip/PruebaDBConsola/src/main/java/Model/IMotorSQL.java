package Model;

import java.sql.ResultSet;

public interface IMotorSQL {
    public void connect();
    public int execute();
    public boolean execute(String sql);
    public ResultSet executeQuery(String sql);

    public void disconnect();
}
