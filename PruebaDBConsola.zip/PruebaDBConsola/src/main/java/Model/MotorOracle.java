package Model;

import java.sql.*;

public class MotorOracle implements IMotorSQL {


    private static final String DRIVER_NAME = "com.mysql.cj.jdbc.Driver";
    private static final String MYSQL_URL = "burgerdata.c5gd2hipkagb.us-east-1.rds.amazonaws.com:3306/BURGERLORD";
    private Connection m_Connection;
    private Statement m_Statement;
    private ResultSet m_ResultSet;


    @Override
    public void connect() {
        try {
            Class.forName(DRIVER_NAME);
            m_Connection = DriverManager.getConnection(MYSQL_URL,"admin","rootroot");
            m_Statement = m_Connection.createStatement();

        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        } catch (SQLException sqlEx) {

            System.out.println(sqlEx.getMessage());

        }
    }

    @Override
    public int execute() {
        return 0;
    }

    @Override
    public boolean execute(String sql) {
        return false;
    }

    @Override
    public ResultSet executeQuery(String sql) {
        try{
            m_ResultSet = m_Statement.executeQuery(sql);
        }
        catch (SQLException sqlEx){
            System.out.println(sqlEx.getMessage());
            m_ResultSet = null;
        }
        return null;
    }


    @Override
    public void disconnect() {
        try {
            if(m_ResultSet != null && !m_ResultSet.isClosed())
            {
                m_ResultSet.close();
            }
            if(m_Statement != null && !m_Statement.isClosed())
            {
                m_Statement.close();
            }
            if(m_Connection != null && !m_Connection.isClosed())
            {
                m_Connection.close();
            }
        }
        catch (SQLException sqlEx)
        {
            System.out.println(sqlEx.getMessage());
        }

    }
}
