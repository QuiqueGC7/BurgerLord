package Model;

public class Customers {

    private int Customer_ID;

    private String Customer_Name_Name;
    private String Customer_SecondName;
    private String Customer_EMail;
    private String Customer_Phone;
    private String Customer_Address;
    private String Customer_Password;


    public int getCustomer_ID() {
        return Customer_ID;
    }

    public void setCustomer_ID(int customer_ID) {
        Customer_ID = customer_ID;
    }

    public String getCustomer_Name_Name() {
        return Customer_Name_Name;
    }

    public void setCustomer_Name_Name(String customer_Name_Name) {
        Customer_Name_Name = customer_Name_Name;
    }

    public String getCustomer_SecondName() {
        return Customer_SecondName;
    }

    public void setCustomer_SecondName(String customer_SecondName) {
        Customer_SecondName = customer_SecondName;
    }

    public String getCustomer_EMail() {
        return Customer_EMail;
    }

    public void setCustomer_EMail(String customer_EMail) {
        Customer_EMail = customer_EMail;
    }

    public String getCustomer_Phone() {
        return Customer_Phone;
    }

    public void setCustomer_Phone(String customer_Phone) {
        Customer_Phone = customer_Phone;
    }

    public String getCustomer_Address() {
        return Customer_Address;
    }

    public void setCustomer_Address(String customer_Address) {
        Customer_Address = customer_Address;
    }

    public String getCustomer_Password() {
        return Customer_Password;
    }

    public void setCustomer_Password(String customer_Password) {
        Customer_Password = customer_Password;
    }

    public Customers(int customer_ID, String customer_Name_Name, String customer_SecondName, String customer_EMail, String customer_Phone, String customer_Address, String customer_Password) {
        Customer_ID = customer_ID;
        Customer_Name_Name = customer_Name_Name;
        Customer_SecondName = customer_SecondName;
        Customer_EMail = customer_EMail;
        Customer_Phone = customer_Phone;
        Customer_Address = customer_Address;
        Customer_Password = customer_Password;
    }
}
