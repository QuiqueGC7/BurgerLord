package Model;

public class Candidaate {

    private int Customer_ID;
    private String Candidate_Name;
    private String Candidate_SecondName;
    private String Candidate_EMail;
    private String Candidate_Phone;
    private String Candidate_CV;
    private int Job_Offer_ID;

    public int getCustomer_ID() {
        return Customer_ID;
    }

    public void setCustomer_ID(int customer_ID) {
        Customer_ID = customer_ID;
    }

    public String getCandidate_Name() {
        return Candidate_Name;
    }

    public void setCandidate_Name(String candidate_Name) {
        Candidate_Name = candidate_Name;
    }

    public String getCandidate_SecondName() {
        return Candidate_SecondName;
    }

    public void setCandidate_SecondName(String candidate_SecondName) {
        Candidate_SecondName = candidate_SecondName;
    }

    public String getCandidate_EMail() {
        return Candidate_EMail;
    }

    public void setCandidate_EMail(String candidate_EMail) {
        Candidate_EMail = candidate_EMail;
    }

    public String getCandidate_Phone() {
        return Candidate_Phone;
    }

    public void setCandidate_Phone(String candidate_Phone) {
        Candidate_Phone = candidate_Phone;
    }

    public String getCandidate_CV() {
        return Candidate_CV;
    }

    public void setCandidate_CV(String candidate_CV) {
        Candidate_CV = candidate_CV;
    }

    public int getJob_Offer_ID() {
        return Job_Offer_ID;
    }

    public void setJob_Offer_ID(int job_Offer_ID) {
        Job_Offer_ID = job_Offer_ID;
    }

    public Candidaate(int customer_ID, String candidate_Name, String candidate_SecondName, String candidate_EMail, String candidate_Phone, String candidate_CV, int job_Offer_ID) {
        Customer_ID = customer_ID;
        Candidate_Name = candidate_Name;
        Candidate_SecondName = candidate_SecondName;
        Candidate_EMail = candidate_EMail;
        Candidate_Phone = candidate_Phone;
        Candidate_CV = candidate_CV;
        Job_Offer_ID = job_Offer_ID;
    }
}


