package Model;

import java.util.ArrayList;

public interface IModel <E> {

    public String fromArraytoJson(ArrayList<E> bean);
    public String toArrayJson(ArrayList<E> bean);
    public String toSqlWhereString();
}
