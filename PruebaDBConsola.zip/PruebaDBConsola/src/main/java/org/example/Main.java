package org.example;

import Model.Roles;
import Model.RolesDao;

import javax.management.relation.Role;
import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        RolesDao aler = new RolesDao();
        ArrayList<Roles> roles = new ArrayList<>();
        roles = aler.findAll(null);//busca todo;
        roles = aler.findAll(new Roles(1,""));

        roles.toString();
    }
}